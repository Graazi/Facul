package Question01.Question02;

public class Main {
    public static void main (String [] args) {
        BinaryTree<String> tree = new BinaryTree <> ();
    
    
    
        int minimumValue = findMinimumValue(root);
        System.out.println("O menor valor na árvore é: " + minimumValue);
    }
    
    
}
