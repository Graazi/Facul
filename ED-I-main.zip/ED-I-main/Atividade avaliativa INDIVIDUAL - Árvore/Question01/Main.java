package Question01;
public class Main {
    public static void main (String [] args) {
    BinaryTree<String> tree = new BinaryTree <> ();



    int contagemDeFolhas = tree.countfolhas(null);
    System.out.println("Quantidade de folhas: " + contagemDeFolhas);
    }
}
