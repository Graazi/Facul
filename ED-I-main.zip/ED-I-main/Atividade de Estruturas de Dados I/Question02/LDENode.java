class LDENode {
    int value;
    LDENode prev;
    LDENode next;
    
    public LDENode(int value) {
        this.value = value;
        this.prev = null;
        this.next = null;
    }
}
