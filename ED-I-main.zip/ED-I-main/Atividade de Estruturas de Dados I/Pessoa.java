class Pessoa {
    String nome;
    int rg;
    
    public Pessoa(String nome, int rg) {
        this.nome = nome;
        this.rg = rg;
    }
}
