package Question02;

public class LDENode {
    
}
