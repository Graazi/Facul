public class Pessoas {
    private String nome;
    private int RG;
    
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public int getRG() {
        return RG;
    }
    public void setRG(int rG) {
        RG = rG;
    }

    
}