class NodeSecundario {
    Termo termo;
    NodeSecundario next;

    public NodeSecundario(Termo termo) {
        this.termo = termo;
        this.next = null;
    }
}
