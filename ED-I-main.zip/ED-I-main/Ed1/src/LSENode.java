public class LSENode {

    private LSENode prox;

    public void setInfo(Funcionario f) {
    }

    public void setProx(LSENode primeiro) {
    }

    public char[] getInfo() {
        return null;
    }

    public LSENode getProx() {
        return null;
    }

}